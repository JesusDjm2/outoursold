<?php
// config.php
// Configuración de base de datos para XAMPP.

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'cliklico_cotiv2');

// Si tu XAMPP usa contraseña en root o un usuario distinto, actualiza estos valores.
?>